import express from "express";
import { pino } from "pino";
import pinoHttp from "pino-http";
import pricesRouter from "./routes/prices";
import paywallRouter from "./routes/paywall";

const logger = pino({ level: "info" });
const app = express();

app.use(pinoHttp({ logger }));
app.use(express.json());
app.use("/api", pricesRouter);
app.use("/api", paywallRouter);

app.get("/api/healthz", (_req, res) => res.json({ ok: true }));

const PORT = process.env.SERVER_PORT || 3001;
app.listen(PORT, () => logger.info(`API server running on :${PORT}`));
