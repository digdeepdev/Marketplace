# Marketplace Migration Bundle

Everything you need to stand up the VerseKit Marketplace as its own standalone Replit project.

---

## 1 — Recommended Replit template

Create a new Repl using the **"React + Express" (Node.js 20+)** template, or start with a blank Node.js repl and follow the structure below.

---

## 2 — Folder structure

```
my-marketplace/
├── client/                  ← React + Vite frontend
│   ├── src/
│   │   ├── assets/          ← copy all image files here (see §4)
│   │   ├── components/
│   │   │   ├── ui/          ← shadcn-style primitives (see §7)
│   │   │   ├── airtime-modal.tsx
│   │   │   ├── merch-coming-soon-modal.tsx
│   │   │   ├── product-card.tsx
│   │   │   └── finalize-modal.tsx
│   │   ├── hooks/
│   │   │   ├── use-wallet.ts
│   │   │   └── use-mobile.ts
│   │   ├── pages/
│   │   │   └── marketplace.tsx
│   │   └── main.tsx
│   ├── index.html
│   └── vite.config.ts
└── server/                  ← Express backend
    └── src/
        ├── routes/
        │   ├── prices.ts
        │   └── paywall.ts
        └── index.ts
```

---

## 3 — npm dependencies to install

### Client (`client/package.json`)
```bash
npm install react react-dom wouter @tanstack/react-query wagmi viem \
  qrcode.react embla-carousel-react embla-carousel-autoplay \
  lucide-react tailwindcss @tailwindcss/vite \
  @radix-ui/react-dialog @radix-ui/react-select \
  class-variance-authority clsx tailwind-merge
npm install -D vite @vitejs/plugin-react typescript @types/react @types/react-dom
```

### Server (`server/package.json`)
```bash
npm install express nodemailer @replit/connectors-sdk pino pino-http
npm install -D typescript @types/express @types/nodemailer tsx
```

---

## 4 — Image assets to copy

Copy these files from `attached_assets/` into `client/src/assets/`:

| File | Used as |
|------|---------|
| `MTN_Nigeria_1780562125673.svg` | MTN logo |
| `Airtel_Nigeria_1780567636022.svg` | Airtel logo |
| `Glo_Nigeria_1780568187203.svg` | Glo logo |
| `T2_Nigeria_1780571958531.svg` | T2 Mobile logo |
| `header_(1)_1780589750503.png` | Carousel background |
| `Threaded_Round_Neck_(1)_1780683904381.png` | Verse Tee product image |
| `quarterzip_hoodie_1780685237495.png` | Verse Hoodie product image |
| `fila_cap_1780685259464.png` | Verse Cap product image |

---

## 5 — Environment variables

Set these in your new Replit project's Secrets panel:

| Variable | Value | Notes |
|----------|-------|-------|
| `NOTIFICATION_EMAIL` | `digdeepeth@gmail.com` | Where purchase alerts are emailed |
| `FROM_EMAIL` | `onboarding@resend.dev` | Sender address (or your own verified domain) |
| `SMTP_HOST` | _(optional)_ | Only needed if using your own SMTP instead of Resend |
| `SMTP_PORT` | _(optional)_ | Default 587 |
| `SMTP_USER` | _(optional)_ | |
| `SMTP_PASS` | _(optional)_ | |

**Resend integration:** In the new project, go to **Tools → Integrations → Resend** and connect it. The `paywall.ts` backend route uses `@replit/connectors-sdk` to call Resend automatically.

---

## 6 — Source files to copy verbatim

### `client/vite.config.ts`
```ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import path from "path";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "src"),
      "@assets": path.resolve(__dirname, "src/assets"),
    },
  },
  server: {
    port: Number(process.env.PORT) || 5173,
    host: "0.0.0.0",
    allowedHosts: true,
    proxy: {
      "/api": "http://localhost:3001",
    },
  },
});
```

### `client/src/main.tsx`
```tsx
import React from "react";
import ReactDOM from "react-dom/client";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { WagmiProvider, createConfig, http } from "wagmi";
import { polygon } from "wagmi/chains";
import { injected, walletConnect } from "wagmi/connectors";
import Marketplace from "./pages/marketplace";
import "./index.css";

const wagmiConfig = createConfig({
  chains: [polygon],
  connectors: [injected(), walletConnect({ projectId: "YOUR_WALLETCONNECT_PROJECT_ID" })],
  transports: { [polygon.id]: http() },
});

const queryClient = new QueryClient();

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <WagmiProvider config={wagmiConfig}>
      <QueryClientProvider client={queryClient}>
        <Marketplace />
      </QueryClientProvider>
    </WagmiProvider>
  </React.StrictMode>
);
```

> **Note:** Get a free WalletConnect project ID at https://cloud.walletconnect.com

---

### `client/src/hooks/use-wallet.ts`
```ts
import { useAccount, useConnect, useDisconnect } from "wagmi";
import { injected } from "wagmi/connectors";

export function useWallet() {
  const { address, chainId, isConnected, isConnecting } = useAccount();
  const { connect } = useConnect();
  const { disconnect } = useDisconnect();

  return {
    address,
    chainId,
    isConnected,
    isConnecting,
    connect: () => connect({ connector: injected() }),
    disconnect,
  };
}
```

### `client/src/hooks/use-mobile.ts`
```ts
import { useEffect, useState } from "react";

export function useIsMobile(breakpoint = 640) {
  const [isMobile, setIsMobile] = useState(window.innerWidth < breakpoint);
  useEffect(() => {
    const handler = () => setIsMobile(window.innerWidth < breakpoint);
    window.addEventListener("resize", handler);
    return () => window.removeEventListener("resize", handler);
  }, [breakpoint]);
  return isMobile;
}
```

---

### `client/src/components/product-card.tsx`
*(copy verbatim from this project)*

The `Product` interface, card layout, blue Buy button (airtime) and purple Buy button (merch) are all self-contained in this file — no changes needed.

---

### `client/src/components/finalize-modal.tsx`
*(copy verbatim from this project)*

The 3-minute progress bar, tx hash input, success/error states are self-contained.

---

### `client/src/components/merch-coming-soon-modal.tsx`
*(copy verbatim from this project)*

SVG cloth rack illustration and "Launching Q4 2026" pill badge are self-contained.

---

### `client/src/components/airtime-modal.tsx`

**Before copying**, update these two constants at the top to match your recipient wallet:

```ts
// Line ~41 — your Polygon wallet that receives VERSE payments
const RECIPIENT_ADDRESS = "0xCF882686d0f8CCB72521C7Cd3A00cfcE63BCDcC7";
```

**API calls** — this file imports React Query hooks from `@workspace/api-client-react`. In the standalone project you have two options:

**Option A (easiest):** Replace the three hook imports with plain `fetch` calls:
```ts
// Replace this block:
import { useGetVerseNairaRate, ... } from "@workspace/api-client-react";

// With:
const [rateData, setRateData] = useState<any>(null);
useEffect(() => {
  if (!open) return;
  fetch("/api/prices/verse-naira").then(r => r.json()).then(setRateData);
}, [open]);
```

**Option B:** Use Orval or openapi-generator to regenerate typed hooks from the API spec, then point them at `/api`.

---

### `client/src/pages/marketplace.tsx`

Update the image imports to use the local `@assets` alias:
```ts
import mtnLogoUrl from "@assets/MTN_Nigeria_1780562125673.svg?url";
import airtelLogoUrl from "@assets/Airtel_Nigeria_1780567636022.svg?url";
// etc. — already correct, just ensure vite.config.ts alias is set up
```

---

### `server/src/routes/prices.ts`
*(copy verbatim from this project)*

Fetches live VERSE/USD from CoinGecko and USDT/NGN, applies 2% fee, caches for 60 seconds.

---

### `server/src/routes/paywall.ts`
*(copy verbatim from this project)*

Handles:
- `GET /api/paywall/verify-verse-balance?walletAddress=0x...` — checks wallet holds ≥2000 VERSE on Polygon
- `POST /api/paywall/confirm-purchase` — verifies tx on-chain, sends email via Resend

---

### `server/src/index.ts`
```ts
import express from "express";
import pricesRouter from "./routes/prices";
import paywallRouter from "./routes/paywall";

const app = express();
app.use(express.json());
app.use("/api", pricesRouter);
app.use("/api", paywallRouter);

const PORT = process.env.SERVER_PORT || 3001;
app.listen(PORT, () => console.log(`API running on :${PORT}`));
```

---

## 7 — UI primitives (shadcn-style)

The components use these Radix-based primitives. You can either:

**Option A:** Install shadcn/ui in the new project:
```bash
npx shadcn@latest init
npx shadcn@latest add dialog select button input badge card carousel
```

**Option B:** Copy the `ui/` folder directly from this project at:
`artifacts/versekit/src/components/ui/`

Files needed: `dialog.tsx`, `select.tsx`, `button.tsx`, `input.tsx`, `badge.tsx`, `card.tsx`, `carousel.tsx`

---

## 8 — Key constants to customise

| Location | Constant | Current value | What to change |
|----------|----------|---------------|----------------|
| `airtime-modal.tsx` | `RECIPIENT_ADDRESS` | `0xCF882...` | Your Polygon wallet |
| `airtime-modal.tsx` | `VERSE_CONTRACT` | `0xc708d6...` | Leave as-is (Verse token) |
| `paywall.ts` | `RECIPIENT_ADDRESS` | `0xCF882...` | Must match frontend |
| `paywall.ts` | `REQUIRED_VERSE` | `2000 VERSE` | Minimum hold to purchase |
| `prices.ts` | `FEE_PERCENT` | `2` | Platform fee % |
| `paywall.ts` | `NOTIFICATION_EMAIL` | `digdeepeth@gmail.com` | Set via env var |

---

## 9 — Quick sanity check

Once running, hit these endpoints to confirm the backend is live:

```bash
# Should return live VERSE price + fee info
curl localhost:3001/api/prices/verse-naira

# Should return balance eligibility
curl "localhost:3001/api/paywall/verify-verse-balance?walletAddress=0xYOUR_ADDRESS"
```
